package com.ssafy.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDdApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootDdApplication.class, args);
	}
}
